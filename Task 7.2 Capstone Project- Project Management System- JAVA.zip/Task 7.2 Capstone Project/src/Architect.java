
public class Architect extends Person {

	public Architect (String name, String lastName,  String email, String physicalAddress, float telephoneNumber) {
		super (name, lastName, email , physicalAddress, telephoneNumber);
	}
	
	// inherent from Person
	}



