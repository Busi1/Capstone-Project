import java.util.Date;

public class Project {
	//Attributes
	String projectName;
	String buildingType;
	int projectNumber;
	String physicalAddress;
	String status;
	int ERFnumber;
	double feeAmount;
	double totalAmountPaid;
	Date  deadlineDate;

	// Methods
	public Project (String projectName, String buildingType,  String physicalAddress, int projectNumber, int ERFnumber, double feeAmount, double totalAmountPaid, Date deadlineDate, String status) {
		this.projectName = projectName;
		this.buildingType = buildingType;
		this.projectNumber = projectNumber;
		this.physicalAddress = physicalAddress;
		this.ERFnumber = ERFnumber;
		this.feeAmount = feeAmount;
		this.totalAmountPaid =totalAmountPaid;
		this.deadlineDate = deadlineDate;
		this.status = status;
	}


	public String getProjectName() {
		return projectName;
	}

	public String getLastBuildingType() {
		return buildingType;
	}

	public String getPhysicalAddress() {
		return physicalAddress;
	}
	
	public String getStatus() {
		return status;
	}


	public String toString() {
		String output = "Name: " + projectName;
		output += "\nLast Building Type:" + buildingType;
		output += "\n Project Number: " + projectNumber; 
		output += "\nAddress:" + physicalAddress;
		output += "\nERF Number : " + ERFnumber;
		output += "\nFee Amount: " + feeAmount;
		output += "\nAmount paid to dat" + totalAmountPaid;
		output += "\nDead Line Date of Project: " + deadlineDate ;
		output  += "\nStatus: " + status;

		return output;
	}

}