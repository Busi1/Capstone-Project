
public class Customer extends Person {

	public Customer (String name, String lastName,  String email, String physicalAddress, float telephoneNumber) {
		super (name, lastName, email , physicalAddress, telephoneNumber);
	}
	
	// inherent from Person
}
		

