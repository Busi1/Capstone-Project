
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;


public class TaskManager {


	public static void main(String[] args)  {
		
		//Capture the details that are used to create a new project
		 
		Project HouseChisoro = new Project ("HouseChisoro", "House", "102 Saint street, Burgundy Este, Cape Town, 7441", 100, 2018020300, 1000000.00, 500000.00, null, "active");
		 System.out.println("New Project");
		 System.out.println(HouseChisoro + "\n");
		 try {
	            FileWriter writer = new FileWriter("MyProject.txt", true);
	            BufferedWriter bufferedWriter = new BufferedWriter(writer);
	            bufferedWriter.write("/nHouseChisoro, House, 102 Saint street Burgundy Este Cape Town 7441, 100, 2018020300, 1000000.00, 500000.00, null, ative");
	            bufferedWriter.write("/nStoreHerren, Store, 77 Saint street, Cape Town 7441, 200, 2018020300, 2000000.00, 900000.00, 22-01-2021, close");
	            bufferedWriter.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
		//Change the due date of the project, total amount of the fee paid to date and //Finalise the project.

		 {
		        boolean fileRead = FileIOTest.readFile();//call the method to read the file with the files name
		        if (fileRead) {//if the read file was successfull
		        	FileIOTest.replacement();//call method to get text to replace, replacement text and output replaced String buffer
		            FileIOTest.writeToFile();
		        }
		 }
	    
		
		//Update a contractor�s contact details.
		 Contractor Busi = new Contractor ("Busi", "Chisoro", "bherrendorfer@hotmail.co.za", "9 Crystal Grove, 0 Amber road, Burgundy Estate", 769887120);
		 System.out.println("Contractor details");
		 System.out.println(Busi + "\n");
		 try {
	            FileWriter writer = new FileWriter("MyPerson.txt", true);
	            BufferedWriter bufferedWriter = new BufferedWriter(writer);
	            bufferedWriter.write("Busi, Chisoro, bherrendorfer@hotmail.co.za, 9 Crystal Grove, 0 Amber road, Burgundy Estate, 769887120");
	            bufferedWriter.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	        } 

		
		

	}



}
