
public class Contractor extends Person {

	public Contractor (String name, String lastName,  String email, String physicalAddress, float telephoneNumber) {
		super (name, lastName, email , physicalAddress, telephoneNumber);
	}
	// inherent from Person
}


