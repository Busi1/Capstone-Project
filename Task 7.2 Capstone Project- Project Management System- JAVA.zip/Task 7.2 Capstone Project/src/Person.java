
public class Person {
	
	public Person() {
	super();
}
	

	// Attributes
	   String name;
	   String lastName;
	   String email;
	   String physicalAddress;
	   float telephoneNumber;
	   
	// Methods
	   public Person (String name, String lastName,  String email, String physicalAddress, float telephoneNumber) {
	      this.name = name;
	      this.lastName = lastName;
	      this.email = email;
	      this.physicalAddress = physicalAddress;
	      this.telephoneNumber = telephoneNumber;
	   }

	   public String getName() {
	      return name;
	   }
	   
	   public String getLastName() {
		      return lastName;
		   }
		
	   public String getEmail() {
	      return email;
	   }
	   
	   public String getPhysicalAdress() {
		      return physicalAddress;
		   }
	   
	  
	   
	   public String toString() {
	      String output = "Name: " + name;
	      output += "\nLast Name:" + lastName;
	      output += "\nEmail: " + email; 
	      output += "\nAddress:" + physicalAddress;
	      output += "\nTel :" + telephoneNumber;
	   
	      return output;
	   }

	}