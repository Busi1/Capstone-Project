# variable to store the dna codes
dna_list = [] 


dna_file = open('DNA.txt', 'r')
for code in dna_file:
    code = [code[i:i+3] for i in range(0, len(code), 3)]
    dna_list.append(code)          # append the dna codes to the dna list
    

dna_list1 = []
for code in dna_list:
    for dna in code:
        dna_list1.append(dna)  # update each dna item to stored each dna list
        
dna_file.close()
print(dna_list1)


# translate function
def translate(dna_input):
    amino_acid = ''
    check_dna = ''
    for code in dna_list1:
        if code in dna_input:
            check_dna = code
    # check if the inputed value is equal to these 5 dna codons
    if check_dna == 'ATT' or check_dna == 'ATC' or check_dna == 'ATA':
        amino_acid = 'Isoleucine'
    elif check_dna == 'CTT' or check_dna == 'CTC' or check_dna == 'CTA' or check_dna == 'CTG' or check_dna == 'TTA' or check_dna == 'TTG':
        amino_acid = 'Leucine'
    elif check_dna == 'GTT' or check_dna == 'GTC' or check_dna == 'GTA' or check_dna == 'GTG':
        amino_acid = 'Valine'
    elif check_dna == 'TTT' or check_dna == 'TTC':
        amino_acid = 'Phenylalanine '
    elif check_dna == 'ATG':
        amino_acid == 'Methionine'
    else:
        amino_acid = 'X'              # change amino based on what user inputed

    print('Amino Acid : ' + amino_acid)
   

def mutate(file_name):
    in_file = open(file_name, "r")
    for in_line in in_file:
        in_line = in_line.rstrip('\n')
        in_line = list(in_line)
        write_to_normal_file = open('normalDNA.txt', 'w')      # write to the normalDna file
        for lower_case in in_line:
            if lower_case == lower_case.lower():               #change to lower case
                index_of_lower = in_line.index(lower_case)
                in_line[index_of_lower] = lower_case.upper()     
        write_to_normal_file.write(str(in_line))               # write to the file the updated A value 
        write_to_normal_file.close()

    # Reading the same file and looping again
    in_file = open(file_name, "r")
    for line in in_file:
        line = line.rstrip('\n')
        line = list(line)
        # The file mutatedDNA.txt must have the same DNA sequence as DNA.txt with the 'a' changed to a 'T'.
        write_to_muatated_file = open('mutatedDNA.txt', 'w')
        for lower_case in line:
            if lower_case == lower_case.lower():
                index_of_lower = line.index(lower_case)
                line[index_of_lower] = 'T'
        write_to_muatated_file.write(str(line)) # write to the file
        write_to_muatated_file.close   
    in_file.close()


# The file normalDNA.txt must have the same DNA sequence as DNA.txt with the 'a' changed to an 'A'.

# Now create a new function, ‘txtTranslate’, that calls the translate function that you wrote in Task 1, to take in text file input.
# Call it on both mutatedDNA.txt and normalDNA.txt, and output both Amino Acid sequences to the user.

# txtTranslate function calls all functions
def txtTranslate():
    user_dna_input = input('Enter a DNA CODE \n')
        # accepts input from user 
    translate(user_dna_input)
    mutate('DNA.txt')

txtTranslate()
